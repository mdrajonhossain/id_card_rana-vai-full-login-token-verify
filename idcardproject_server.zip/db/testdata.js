student_name
class_roll
blood_group
student_phone_number
parents_phone_number
degree
department
section
session
group
picture


student_name: req.body.student_name,
class_roll: req.body.class_roll,
blood_group: req.body.blood_group,
student_phone_number: req.body.student_phone_number,
parents_phone_number: req.body.parents_phone_number,
degree: req.body.degree,
department: req.body.department,
section: req.body.section,
session: req.body.session,
group: req.body.group,
picture: req.body.picture

 

student_name: "req.body.student_name",
class_roll: "req.body.class_roll",
blood_group: "req.body.blood_group",
student_phone_number: "req.body.student_phone_number",
parents_phone_number: "req.body.parents_phone_number",
degree: "req.body.degree",
department: "req.body.department",
section: "req.body.section",
session: "req.body.session",
group: "req.body.group",
picture: "req.body.picture"

 